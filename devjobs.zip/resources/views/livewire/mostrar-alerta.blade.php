<div >
    <p class="mt-2 bg-red-100 border-l-4 border-red-600 text-red-600 font-bold p-2 text-md rounded-md">{{$message}}</p>
</div>
