<h1 class="text-4xl">
    Dev<span class="font-bold">Jobs</span>
</h1>