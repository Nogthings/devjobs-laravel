<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->slot('header', null, []); ?> 
       <h2 class="font-semibold text-xl text-gray-800 leading-tight">
           <?php echo e(__('Notificaciones')); ?>

       </h2>
    <?php $__env->endSlot(); ?>

   <div class="py-12">
       <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
           <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
               <div class="p-6 text-gray-900">
                  <h1 class="text-2xl font-semibold text-center mb-10">Mis notificaciones</h1>

                  <?php $__empty_1 = true; $__currentLoopData = $notificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <div class="p-5 border border-gray-200 lg:flex lg:justify-between lg:items-center rounded mb-1">
                     <div>
                        <p>Tienes un nuevo candidato en: <span class="font-bold"><?php echo e($notificacion->data['nombre_vacante']); ?></span></p>
                        <p> <span class="font-bold"><?php echo e($notificacion->created_at->diffForHumans()); ?></span></p>
                     </div>
                     <div class="mt-5 lg:mt-0">
                        <a href="<?php echo e(route('candidatos.index', $notificacion->data['id_vacante'])); ?>" class="bg-indigo-700 p-3 text-sm uppercase font-bold text-white rounded-lg">Ver Candidatos</a>
                     </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                     <p class="text-center text-gray-600">No hay notificaciones nuevas</p>
                  <?php endif; ?>
               </div>
           </div>
       </div>
   </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\workspace\Web\devjobs\resources\views/notificaciones/index.blade.php ENDPATH**/ ?>