<h1 class="text-4xl">
    Dev<span class="font-bold">Jobs</span>
</h1><?php /**PATH C:\workspace\Web\devjobs\resources\views/components/application-logo.blade.php ENDPATH**/ ?>