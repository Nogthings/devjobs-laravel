<div>
    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <?php $__empty_1 = true; $__currentLoopData = $vacantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="p-6 bg-white border-b border-gray-200">
            <div class="space-y-3">
                <a href="<?php echo e(route('vacantes.show', $vacante->id)); ?>" class="text-xl font-semibold">
                    <?php echo e($vacante->titulo); ?>

                </a>
                <div class="md:flex justify-between">
                    <p class="text-sm font-semibold text-gray-600"><?php echo e($vacante->empresa); ?></p>
                    <p class="text-sm text-gray-500">Ultimo dia: <?php echo e($vacante->ultimo_dia->format('d/m/Y')); ?></p>
                </div>
            </div>
            <div class="flex md:flex-row flex-col items-stretch md:justify-end mt-2 gap-3">
                <a href="<?php echo e(route('candidatos.index', $vacante)); ?>" class="bg-slate-800 py-2 px-4 rounded-lg text-white text-xs font-bold uppercase text-center">
                    <?php echo e($vacante->candidatos->count()); ?> Candidatos
                </a>
                <a href="<?php echo e(route('vacantes.edit', $vacante->id)); ?>" class="bg-blue-800 py-2 px-4 rounded-lg text-white text-xs font-bold uppercase text-center">
                    Editar
                </a>
                <button wire:click="$emit('mostrarAlerta',<?php echo e($vacante->id); ?>)" class="bg-red-800 py-2 px-4 rounded-lg text-white text-xs font-bold uppercase text-center">
                    Eliminar
                </button>
            </div>
         </div>   
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
         
         <div class="p-6 bg-white">
            <p class="text-sm uppercase text-center">No hay vacantes</p>
         </div>
      
        <?php endif; ?>
    
    </div>
    
    <div class="flex justify-center mt-10">
        <?php echo e($vacantes->links()); ?>

    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        Livewire.on('mostrarAlerta', vacanteId=>{
                Swal.fire({
                    title: '¿Eliminar la vacante?',
                    text: "No puedes deshacer esta accion.",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Si',
                    cancelButtonText: 'Cancelar'
            }).then((result) => {
            if (result.isConfirmed) {
                //eliminar la vacante desde el servidor
                Livewire.emit('eliminarVacante', vacanteId)

                Swal.fire(
                'Se elimino la vacante',
                'Eliminado correctamente',
                'success'
                )
            }
            })
        })

    </script>
<?php $__env->stopPush(); ?><?php /**PATH C:\workspace\Web\devjobs\resources\views/livewire/mostrar-vacantes.blade.php ENDPATH**/ ?>