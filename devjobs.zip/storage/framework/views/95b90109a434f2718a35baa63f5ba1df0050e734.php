<div class="p-5">
    <div class="mb-5">
        
    <?php if(auth()->guard()->guest()): ?>
        <div class="mb-10 bg-gray-50 border border-dashed p-5 text-center">
            <p>
                ¿Deseas aplicar a esta vacante? <a href="<?php echo e(route('register')); ?>" class="font-bold text-indigo-700">Obten una cuenta para aplicar a esta u otras vacantes</a>
            </p>
        </div>
    <?php endif; ?>
    
        <h3 class="font-semibold text-2xl text-gray-800">
            <?php echo e($vacante->titulo); ?>

        </h3>
        <div class="md:grid md:grid-cols-2 bg-gray-50 p-4 my-5 rounded">
            <p class="text-sm font-light my-3 uppercase">Empresa: <span class="normal-case font-semibold"><?php echo e($vacante->empresa); ?></span></p>
            <p class="text-sm font-light my-3 uppercase">Ultimo dia: <span class="normal-case font-semibold"><?php echo e($vacante->ultimo_dia->toFormattedDateString()); ?></span></p>
            <p class="text-sm font-light my-3 uppercase">Categoria: <span class="normal-case font-semibold"><?php echo e($vacante->categoria->categoria); ?></span></p>
            <p class="text-sm font-light my-3 uppercase">Salario: <span class="normal-case font-semibold"><?php echo e($vacante->salario->salario); ?></span></p>
        </div>
    </div>

    <div class="md:grid md:grid-cols-6 gap-4">
        <div class="md:col-span-2">
            <img src="<?php echo e(asset('storage/vacantes/'.$vacante->imagen)); ?>" alt="imagen vacante">
        </div>
        <div class="md:col-span-4">
            <h2 class="text-2xl font-bold mb-5">Descripcion del puesto</h2>
            <p><?php echo e($vacante->descripcion); ?></p>
        </div>
    </div>

    <?php if(auth()->guard()->check()): ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('create', App\Models\Vacante::class)): ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('postular-vacante', ['vacante' => $vacante])->html();
} elseif ($_instance->childHasBeenRendered('l3306669482-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3306669482-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3306669482-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3306669482-0');
} else {
    $response = \Livewire\Livewire::mount('postular-vacante', ['vacante' => $vacante]);
    $html = $response->html();
    $_instance->logRenderedChild('l3306669482-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php endif; ?>     
    <?php endif; ?>


</div>
<?php /**PATH C:\workspace\Web\devjobs\resources\views/livewire/mostrar-vacante.blade.php ENDPATH**/ ?>