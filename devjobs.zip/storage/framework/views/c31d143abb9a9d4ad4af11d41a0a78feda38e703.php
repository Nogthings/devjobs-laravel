<div>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('filtrar-vacantes', [])->html();
} elseif ($_instance->childHasBeenRendered('l98663190-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l98663190-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l98663190-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l98663190-0');
} else {
    $response = \Livewire\Livewire::mount('filtrar-vacantes', []);
    $html = $response->html();
    $_instance->logRenderedChild('l98663190-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto">
            <h3 class="font-bold text-4xl text-gray-800 mb-12">Vacantes disponibles</h3>

            <div class="bg-white shadow-sm rounded-lg p-6 divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = $vacantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="md:flex md:justify-between md:items-center py-5">
                        <div class="md:flex-1">
                            <a href="<?php echo e(route('vacantes.show', $vacante->id)); ?>" class="text-3xl font-bold text-gray-600"><?php echo e($vacante->titulo); ?></a>
                            <p class="text-base text-gray-600 mb-3"><?php echo e($vacante->empresa); ?></p>
                            <p class="font-bold text-gray-600 text-xs">
                                Ultimo dia para postularse:
                                <span class="font-normal"><?php echo e($vacante->ultimo_dia->format('d/m/Y')); ?></span>
                            </p>
                        </div>

                        <div class="mt-5 md:mt-0">
                            <a href="<?php echo e(route('vacantes.show', $vacante->id)); ?>" class="bg-indigo-700 p-3 text-sm uppercase font-bold text-white rounded-lg block text-center">Ver vacante</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="p-3 text-center text-sm text-gray-600">No hay vacantes aun</p>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>
<?php /**PATH C:\workspace\Web\devjobs\resources\views/livewire/home-vacantes.blade.php ENDPATH**/ ?>