<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->slot('header', null, []); ?> 
       <h2 class="font-semibold text-xl text-gray-800 leading-tight">
           <?php echo e(__('Mis Vacantes')); ?>

       </h2>
    <?php $__env->endSlot(); ?>

   <div class="py-12">
       <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <?php if(session()->has('mensaje')): ?>
                <div class="uppercase border border-green-600 bg-green-100 text-green-900 font-bold p-2 my-3">
                    <?php echo e(session('mensaje')); ?>

                </div>
            <?php endif; ?>

           <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('mostrar-vacantes', [])->html();
} elseif ($_instance->childHasBeenRendered('a8AmaBH')) {
    $componentId = $_instance->getRenderedChildComponentId('a8AmaBH');
    $componentTag = $_instance->getRenderedChildComponentTagName('a8AmaBH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('a8AmaBH');
} else {
    $response = \Livewire\Livewire::mount('mostrar-vacantes', []);
    $html = $response->html();
    $_instance->logRenderedChild('a8AmaBH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
       </div>
   </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\workspace\Web\devjobs\resources\views/vacantes/index.blade.php ENDPATH**/ ?>