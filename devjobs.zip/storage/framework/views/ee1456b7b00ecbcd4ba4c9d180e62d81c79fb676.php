<div >
    <p class="mt-2 bg-red-100 border-l-4 border-red-600 text-red-600 font-bold p-2 text-md rounded-md"><?php echo e($message); ?></p>
</div>
<?php /**PATH C:\workspace\Web\devjobs\resources\views/livewire/mostrar-alerta.blade.php ENDPATH**/ ?>